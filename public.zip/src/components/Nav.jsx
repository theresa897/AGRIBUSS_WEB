import '../../dist/output.css'

export default function Nav(){
	return(
		<p class="text-slate-500">Helloworld</p>
	)
}


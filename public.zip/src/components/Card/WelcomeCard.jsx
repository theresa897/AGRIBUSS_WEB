
export default function WelcomeCard(){
	return(
		<>
			<div>
				<p>Here</p>
			</div>
		</>
	)
}
import img2 from '../assets/images/boy7.png'
import img3 from '../assets/images/boy8.png'
import img4 from '../assets/images/boy1.png'
import img5 from '../assets/images/boy2.png'
import img6 from '../assets/images/boy3.png'


import pers2 from '../assets/images/boy7.png'
import pers3 from '../assets/images/boy8.png'
import pers4 from '../assets/images/boy1.png'
import pers5 from '../assets/images/boy2.png'
import pers6 from '../assets/images/boy3.png'
import pers7 from '../assets/images/pers1.png'
import pers8 from '../assets/images/pers2.png'
import pers9 from '../assets/images/pers10.png'
import pers10 from '../assets/images/pers11.png'
import pers11 from '../assets/images/pers12.png'
import pers12 from '../assets/images/pers13.png'
import pers13 from '../assets/images/pers14.png'
import pers14 from '../assets/images/pers15.png'
import pers15 from '../assets/images/pers16.png'

export const farmerData = 
[
     {
         id:"#125abc1",
         firstname: "Dzeufack Nouboudem",
         lastname: "theresa",
         email: "theresa@gmail.com",
         gender: "female",
         tel: "655998822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers14,
         verified:true,
         farmlocate: "Yaounde, messasi",
         tradeunion: "false"
     }, 
     {
         id:"#125abc2",
         firstname: "Kameni Sepdeu",
         lastname: "Ange",
         email: "ange@gmail.com",
         gender: "male",
         tel: "655898822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers2,
         verified:true,
         farmlocate: "Yaounde, awai",
         tradeunion: "false"
     },
     {
         id:"#125abc3",
         firstname: "Mbah Tolos",
         lastname: "Royce",
         email: "royce@gmail.com",
         gender: "male",
         tel: "651998822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers3,
         verified:true,
         farmlocate: "Yaounde, mendong",
         tradeunion: "false"
     },
     {
         id:"#125abc4",
         firstname: "Nganou ",
         lastname: "Marcelin",
         email: "marcel@gmail.com",
         gender: "male",
         tel: "659998822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers5,
         verified:false,
         farmlocate: "Yaounde,     odza",
         tradeunion: "false"
     },
     {
         id:"#125abc5",
         firstname: "Kempa",
         lastname: "Marie Jeanne",
         email: "marie@gmail.com",
         gender: "female",
         tel: "675998822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers5,
         verified:false,
         farmlocate: "Yaounde, Happy",
         tradeunion: "false"
     },
     {
         id:"#125abc6",
         firstname: "Sandr Norvelle",
         lastname: "Brith",
         email: "brith@gmail.com",
         gender: "female",
         tel: "685998822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers6,
         verified:true,
         farmlocate: "Yaounde, Ekonou",
         tradeunion: "false"
     },
     {
         id:"#125abc7",
         firstname: "Taneu Monette",
         lastname: "Sempai",
         email: "sempai@gmail.com",
         gender: "male",
         tel: "655995822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers8,
         verified:false,
         farmlocate: "Yaounde, amadou",
         tradeunion: "false"
     },
     {
         id:"#125abc5",
         firstname: "Kempa",
         lastname: "Marie Jeanne",
         email: "marie@gmail.com",
         gender: "female",
         tel: "675998822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers5,
         verified:false,
         farmlocate: "Yaounde, Happy",
         tradeunion: "false"
     },
     {
         id:"#125abc6",
         firstname: "Sandr Norvelle",
         lastname: "Brith",
         email: "brith@gmail.com",
         gender: "female",
         tel: "685998822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers6,
         verified:true,
         farmlocate: "Yaounde, Ekonou",
         tradeunion: "false"
     },
     {
         id:"#125abc7",
         firstname: "Taneu Monette",
         lastname: "Sempai",
         email: "sempai@gmail.com",
         gender: "male",
         tel: "655995822",
         city: "Yaounde",
         dob: "09/09/2000",
         image: pers8,
         verified:false,
         farmlocate: "Yaounde, amadou",
         tradeunion: "false"
     },
]
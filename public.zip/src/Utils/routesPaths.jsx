
const store = 
[
	{
		path: '/register',
		component: ''
	}
]
export function hello(): string {
	return "Hello world"
}
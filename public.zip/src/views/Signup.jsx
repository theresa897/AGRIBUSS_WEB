import Register from '../components/pages/Register.jsx';

export default function SignUp(){
	return(
		<Register/>
	)
}
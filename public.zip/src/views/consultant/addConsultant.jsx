
export default function AddConsultant (){
    return(
        <p>Consultant</p>
    )
}
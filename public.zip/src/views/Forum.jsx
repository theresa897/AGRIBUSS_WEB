export default function Forum(){
	return(
		<>
			<div>
				<p>Forum</p>
			</div>
		</>
	)
}	
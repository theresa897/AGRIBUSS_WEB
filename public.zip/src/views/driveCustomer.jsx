
export default function DriverCustomer(){
	return(
		<>
			<p>Welcome</p>
		</>	
	)
}
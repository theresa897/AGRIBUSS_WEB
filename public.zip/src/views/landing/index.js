import LandingPage from "./landingPage";

export {LandingPage}
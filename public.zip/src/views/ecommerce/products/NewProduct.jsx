
export default function NewProduct() {
    return(
        <p>Add Product</p>
    )
}
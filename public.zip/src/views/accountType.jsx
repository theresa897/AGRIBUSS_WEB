export default function AccountType(){
    return(
        <p>Account type</p>
    )
}
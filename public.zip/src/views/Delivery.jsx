export default function Delivery(){
	return(
		<>
			<div>
				<p>Delivery</p>
			</div>
		</>
	)
}
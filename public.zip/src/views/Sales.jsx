export default function Sales(){
	return(
		<>
			<div>
				<p>Sales</p>
			</div>
		</>
	)
}
import Login from '../components/pages/login.jsx';

export default function SignIn(){
	return(
		<Login/>
	)
}